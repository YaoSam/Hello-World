#include <iostream>
using namespace std;
//#define DEBUG
/*ûʲô��˵��*/
const float PI = 3.1415;
class Circle
{
private:
	float radius;
public:
	Circle(float R)
	{
		radius = R;
	}
	float ShowArea()
	{
		cout << "Area is:" << radius*radius*PI;
		return radius*radius*PI;
	}
	float ShowPerimeter()
	{
		cout << "Perimeter is:" << radius * 2 * PI;
		return radius * 2 * PI;
	}
};
int main()
{
#ifdef DEBUG
	FILE *err; //��������freopen_s����ʵ��û�õġ�
	freopen_s(&err, "in.txt", "r", stdin);
	freopen_s(&err, "out.txt", "w", stdout);
#endif
	Circle a(2);
	a.ShowArea();

#ifndef DEBUG
	printf("\n");
	system("pause");
#endif // !DEBUG
	return 0;
}