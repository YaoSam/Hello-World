void f(int x, int y)
{
	int t;
	t = x + y;
}